All solutions will be presented once they are found.
The algorithms are being put to use on one tower at the time. The path and information on the solutions are being plotted to the user.

*BFS uses some time to find teh solution on high towers, keep this in mind.

Script is tested and run in this environment.

Python 3.11.2
(venv)
Package         Version
--------------- -------
contourpy       1.2.0
cycler          0.12.1
fonttools       4.47.2
kiwisolver      1.4.5
matplotlib      3.8.2
numpy           1.26.3
packaging       23.2
pillow          10.2.0
pip             24.0
psutil          5.9.8
pyparsing       3.1.1
python-dateutil 2.8.2
setuptools      65.5.0
six             1.16.0